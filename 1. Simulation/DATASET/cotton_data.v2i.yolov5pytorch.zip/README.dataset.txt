# cotton_data > 2024-02-05 7:20pm
https://universe.roboflow.com/proj1-gyxkz/cotton_data

Provided by a Roboflow user
License: CC BY 4.0

